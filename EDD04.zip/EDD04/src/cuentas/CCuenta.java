/** Esta clase simula el funcionamiento de una cuenta bancaria*/
package cuentas;

public class CCuenta {


    private String nombre;
    private String cuenta;
    private double saldo;
    private double tipoInterés;
/** Atributos*/
    public CCuenta()
    {
    }

    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        nombre =nom;
        cuenta=cue;
        saldo=sal;
    }

    public double estado()
    {
        return saldo;
    }
        /**return devuelve el saldo de la cuenta*/
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        saldo = saldo + cantidad;
    }

    public void retirar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No se hay suficiente saldo");
        saldo = saldo - cantidad;
    }

		String getNombre() {
			return nombre;
		}
		
		void setNombre(String nombre) {
			this.nombre = nombre;
		}
		
		String getCuenta() {
			return nombre;
		}
		
		void setCuenta(String cuenta) {
			this.cuenta = cuenta;
		}
		
		double getSaldo() {
			return saldo;
		}
		
		void setSaldo(double saldo) {
			this.saldo = saldo;
		}
		
		double getTipoInterés() {
			return tipoInterés;
		}
		
		void setTipoInterés(double tipoInterés) {
			this.tipoInterés = tipoInterés;
		}
}
